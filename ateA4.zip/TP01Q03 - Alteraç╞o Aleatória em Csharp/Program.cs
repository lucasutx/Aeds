﻿using System;

class Program
{
  public static void Main(string[] args)
  {

    string palavra = Console.ReadLine();//Leitura

    char[] aux = palavra.ToCharArray();//transformação em vetor

    Random aleatorio = new Random();// Sorteio de números

    int num = aleatorio.Next(12, 13);//1° número sorteado
    int num2 = aleatorio.Next(3, 4);//2° número sorteado


    Console.WriteLine("valores: m e d ");
    while (palavra != "FIM")
    {
      substitui(aux,num,num2);
      palavra = Console.ReadLine();//Leitura
      aux = palavra.ToCharArray();//transformação em vetor

    }



  }

  public static void substitui(char[] aux,int num,int num2)
  {

    char[] alfabeto = new char[26];//Alocação para as letras do alfabeto
    char[] nova = new char[aux.Length];


    for (int i = 0; i < alfabeto.Length; i++)//Preenchimento com as letras
    {
      alfabeto[i] = (char)(i + 97);
    }

    for (int i = 0; i < aux.Length; i++)
    {
      for (int j = 0; j < alfabeto.Length; j++)
      {
        if (aux[i] == alfabeto[num])
        {
          nova[i] = alfabeto[num2];
        }
        else
        {
          nova[i] = aux[i];
        }
      }
    }

    string novo = new string(nova);
    Console.WriteLine(novo);
  }
}
