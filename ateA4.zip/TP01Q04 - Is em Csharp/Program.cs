﻿using System;

class Program
{
  public static void Main(string[] args)
  {
    string palavra = Console.ReadLine();
    char[] aux = palavra.ToCharArray();

    while (palavra != "FIM")
    {

      Console.WriteLine(vogais(aux, palavra) + " " + consoante(aux) + " " + inteiro(aux) + " " + real(aux, palavra));


      palavra = Console.ReadLine();
      aux = palavra.ToCharArray();
    }

  }


  public static string vogais(char[] aux, string palavra)
  {
    char[] vogais = new char[10] { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
    string verificador;
    int conta = 0;

    for (int i = 0; i < palavra.Length; i++)
    {
      for (int j = 0; j < vogais.Length; j++)
      {
        if (palavra[i] == vogais[j])
        {
          conta++;
        }
      }
    }

    if (conta == aux.Length)
    {
      verificador = "SIM";
    }
    else
    {
      verificador = "NAO";
    }


    return verificador;

  }

  public static string consoante(char[] aux)
  {
    char[] vogais = new char[10] { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
    char[] consoantes = new char[21] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z' };
    char[] consoantesM = new char[21] { 'B', 'C', 'D', 'E', 'F', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z' };

    int conta = 0;
    string verificador;

    for (int i = 0; i < aux.Length; i++)
    {
      for (int j = 0; j < vogais.Length; j++)
      {
        if (aux[i] == consoantes[j] || aux[i] == consoantesM[j])
        {
          conta++;
        }
      }
    }

    if (conta == aux.Length)
    {
      verificador = "SIM";
    }
    else
    {
      verificador = "NAO";
    }


    return verificador;

  }

  public static string inteiro(char[] aux)
  {
    string verificador;
    int conta = 0;

    for (int i = 0; i < aux.Length; i++)
    {
      if (Char.IsDigit(aux[i]))
      {
        conta++;
      }
    }
    if (conta == aux.Length)
    {
      verificador = "SIM";
    }
    else
    {
      verificador = "NAO";
    }
    return verificador;
  }

  public static string real(char[] aux, string palavra)
  {
    int conta = 0;
    string verifica;
    char[] numeros = new char[10] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    string[] num = new string[aux.Length];

    for (int i = 0; i < palavra.Length; i++)
    {
      for (int j = 0; j < numeros.Length; j++)
      {
        if (palavra[i] == numeros[j])
        {
          num[i] = (numeros[j].ToString());
        }
      }
    }

    for (int i = 0; i < num.Length; i++)
    {
      if(String.IsNullOrWhiteSpace(num[i]))
      {
        conta++;
      }
    }

    


    if (conta < 2)
    {
      verifica = "SIM";
    }
    else
    {
      verifica = "NAO";
    }
    return verifica;

  }

}





