﻿using System;


class Program
{
  public static void Main(string[] args)
  {
    string frase = Console.ReadLine();
    char[] aux = frase.ToCharArray();

    while (frase != "FIM")
    {
      codificacao(aux);
      frase = Console.ReadLine();
      aux = frase.ToCharArray();

    }


  }

  public static void codificacao(char[] aux)
  {
    char[] letras = new char[26];
    char[] letrasM = new char[26];
    char[] numeros = new char[10];
    char[] simbolos = new char[15];
    

    char[] nova = new char[aux.Length];




    for (int i = 0; i < letras.Length; i++)
    {
      letras[i] = (char)(i + 97);
    }

    for (int i = 0; i < simbolos.Length; i++)
    {
      simbolos[i] = (char)(i + 32);
    }

    for (int i = 0; i < letrasM.Length; i++)
    {
      letrasM[i] = (char)(i + 65);
    }

    for (int i = 0; i < numeros.Length; i++)
    {
      numeros[i] = (char)(i + 48);
    }

    for (int i = 0; i < aux.Length; i++)
    {
      for (int j = 0; j < letras.Length; j++)
      {
        if (aux[i] == letrasM[j])
        {
          nova[i] = letrasM[j + 3];

        }
        else if (aux[i] == 'z')
        {
          nova[i] = '}';
        }
        else if (aux[i] == letras[j])
        {
          nova[i] = letras[j + 3];
        }

        else if (aux[i] == ' ')
        {
          nova[i] = simbolos[3];
        }
        else if (aux[i] == '-')
        {
          nova[i] = '0';
        }
        else if (aux[i] == '.')
        {
          nova[i] = '1';
        }
        else if (aux[i] == ',')
        {
          nova[i] = '/';
        }
        else if (aux[i] == '&')
        {
          nova[i] = ')';
        }
        else if (aux[i] == simbolos[7])
        {
          nova[i] = '*';
        }

        else if (aux[i] == '0' || aux[i] == '1' || aux[i] == '2' || aux[i] == '3' || aux[i] == '4' || aux[i] == '5' || aux[i] == '6' || aux[i] == '7' || aux[i] == '8' || aux[i] == '9')
        {
          for (int k = 0; k < aux.Length; k++)
          {
            for (int l = 0; l < numeros.Length; l++)
            {


              if (aux[k] == numeros[l])
              {

                if (aux[k] == '7')
                {
                  nova[k] = ':';
                }
                else if (aux[k] == '8')
                {
                  nova[k] = ';';
                }
                else if (aux[k] == '9')
                {
                  nova[k] = '<';
                }
                else
                {
                nova[k] = (numeros[l+3]);
                }
              }



            }
          }
        }

      }
    }


    string codificado = new string(nova);


    Console.WriteLine(codificado);





  }


}


