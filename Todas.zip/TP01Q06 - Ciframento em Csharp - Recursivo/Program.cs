﻿using System;


class Program
{
  public static void Main(string[] args)
  {
    string frase = Console.ReadLine();

    while (frase != "FIM")
    {
      Console.WriteLine(cod(frase, 3));
      frase = Console.ReadLine();

    }


  }


  static string cod(string mensagem, int chave)
  {

    if (mensagem.Length == 0) // caso base da recursão
    {
      return "";
    }
    else
    {
      char primeiro = mensagem[0];
      string resto = mensagem.Substring(1);

      if (Char.IsUpper(primeiro))
      {
        char cifrado = (char)(((int)primeiro + chave - 65) % 26 + 65); // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
      if (primeiro== 'z')
      {
        char cifrado = '}'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }

      else if (Char.IsLetter(primeiro))
      {
        char cifrado = (char)(((int)primeiro + chave - 97) % 26 + 97); // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva

      }
      else if (char.IsDigit(primeiro))
      {
        char cifrado = (char)(((int)primeiro + chave - 48) % 26 + 48); // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
      else if (primeiro== ' ')
      {
        char cifrado = '#'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
      else if (primeiro== '-')
      {
        char cifrado = '0'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
      else if (primeiro== '.')
      {
        char cifrado = '1'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
       else if (primeiro== ',')
      {
        char cifrado = '/'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
      else if (primeiro== '&')
      {
        char cifrado = ')'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }
      else if (primeiro == '\'')
      {
        char cifrado = '*'; // aplicando o deslocamento
        return cifrado + cod(resto, chave); // chamada recursiva
      }



      else
      {
        return primeiro + cod(resto, chave); // chamada recursiva
      }
    }
  }


}


