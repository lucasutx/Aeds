﻿using System;

class Program{
  public static void Main(string[]args)
  {

    string palavra = Console.ReadLine();
    char[] palavra2=palavra.ToCharArray();

    while(palavra != "FIM")
    {
      verifica(palavra2);
       palavra = Console.ReadLine();
       palavra2 = palavra.ToCharArray();

    }


  }


  public static void verifica(char[] palavra2)
  {
      char[] reverso= new char[palavra2.Length];
      int conta=0;
    for(int i=palavra2.Length-1;i>=0;i--)
    {
      reverso[conta]=palavra2[i];
      conta++;

    }

    string aux = new string(palavra2);
    string aux2 = new string(reverso);

    if(aux.Contains(aux2))
    {
      Console.WriteLine("SIM");
    }else{
      Console.WriteLine("NAO");
    }



  }
}
