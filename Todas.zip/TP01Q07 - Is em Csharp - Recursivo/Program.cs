﻿using System;

class Program
{
  public static void Main(string[] args)
  {
    string palavra = Console.ReadLine();
    char[] aux = new char[palavra.Length];

    while (palavra != "FIM")
    {

      Console.WriteLine(vogais(palavra) + " " + consoante(palavra) + " " + inteiros(palavra, aux) + " " + real(palavra, 0));
      palavra = Console.ReadLine();
      aux = new char[palavra.Length];
    }

  }

  public static string vogais(string palavra)
  {

    string verifica = "SIM";
    if (palavra.Length == 0)
    {
      return verifica;
    }
    else if (!("aeiouAEIOU".Contains(palavra[0])))
    {

      verifica = "NAO";
      return verifica;

    }
    else
    {
      return vogais(palavra.Substring(1));
    }
  }

  public static string consoante(string palavra)
  {
    string verifica = "SIM";
    if (palavra.Length == 0)
    {
      return verifica;
    }
    else if (!("bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ".Contains(palavra[0])))
    {
      verifica = "NAO";
      return verifica;
    }
    else
    {
      return consoante(palavra.Substring(1));
    }
  }

  public static string inteiros(string palavra, char[] aux)
  {
    string verifica = "SIM";
    if (palavra.Length == 0)
    {
      return verifica;
    }
    else if (("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".Contains(palavra[0])))
    {
      verifica = "NAO";
      return verifica;
    }
    else if ((".,").Contains(palavra[0]))
    {
      verifica = "NAO";
      return verifica;
    }
    else
    {
      return inteiros(palavra.Substring(1), aux);
    }

  }

  public static string real(string palavra, int contador)
  {
    string verifica = "SIM";



    if (palavra.Length == 0)
    {
      return verifica;
    }
    else if (("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".Contains(palavra[0])))
    {
      verifica = "NAO";
      return verifica;
    }
    else if (".,".Contains(palavra[0]))
    {
      //Console.WriteLine(contador++);
      return real(palavra.Substring(1), ++contador);
    }

    if (contador > 1)
      {
        verifica = "NAO";
        return verifica;
      }




    return real(palavra.Substring(1), contador);


  }




}

