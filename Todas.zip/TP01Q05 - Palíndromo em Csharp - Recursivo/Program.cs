﻿using System;

class Program
{
  public static void Main(string[] args)
  {
    string palavra = Console.ReadLine();
    char[] aux = new char[palavra.Length];

    aux = palavra.ToCharArray();

    while (palavra != "FIM")
    {
      if(recebe(0, aux)== true)
      {
        Console.WriteLine("SIM");
      }else
      {
        Console.WriteLine("NAO");
      }


      palavra = Console.ReadLine();
      aux = new char[palavra.Length];
      aux = palavra.ToCharArray();
    }
  }

  public static bool recebe(int contador, char[] aux)
  {
    bool verifica = false;


    if (aux.Length / 2 >= contador)
    {
      if (aux[contador] == aux[aux.Length-contador-1])
      {

        return recebe(contador+1,aux);
      }
    }

    if (contador >= aux.Length/2)
    {
      return true;
    }
    return verifica;
  }
}

